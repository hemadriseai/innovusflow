
import re,time
import csv

#----------------------------------------------------------------------------

#timing report format must contain "fanout" and "arrivaltime" and clock type  should also be full type only for REG2REG

#file_path ="/nas/nas_v1/Innovus_trials/users/udaykiran/ibex_stylus/1.0/blockname/PD/username/run1/reports/Place/place.report_timing.rpt"
#file_path="/nas/nas_v1/Innovus_trials/users/udaykiran/ibex_stylus/1.0/blockname/PD/username/run1/scripts/timing_place10"
file_path="report_timing.rpt"
file_path1="report_timing.hold.rpt"

## cells group files
#cells_group_file="/nas/nas_v1/Innovus_trials/users/udaykiran/ibex_stylus/1.0/blockname/PD/username/run1/scripts/cell_name_type"
cells_group_file="cell_name_type.csv"


# NET LENGTH FILE PATH
#net_length_file="/nas/nas_v1/Innovus_trials/users/udaykiran/ibex_stylus/1.0/blockname/PD/username/run1/scripts/wire_length"
net_length_file="wire_length"


##output_file_names:

output_file = "timing_report_setup.csv"  # Define your output file path
output_file1 ="timing_report_hold.csv"

#--------------------------------------------------------------------------------
def save_to_csv(results, output_file,fieldnames,a,output_file):
    if a ==1:
        with open(output_file, 'w', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames)
            writer.writeheader()
            writer.writerows(results)
            csvfile.write("\n")
            
    else:
        with open(output_file, 'a', newline='') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames)
           # writer.writeheader()
            writer.writerows(results)
            csvfile.write("\n")
 
#--------------------------------------------------------------------------
def func1(path,net_length_file,cells_group_file):
    fanout = 0
    net_delay = 0
    results = []  # To store results for CSV
    
    with open(path, 'r') as data:
        b = data.read()
    with open(net_length_file,'r') as nets:
        nets_data=nets.read()
    with open(cells_group_file,'r') as cells:
         cell_data=cells.read()
    #spliting_of_path = re.split(r'Path:', b)    #use this in report if path is in this  format [Path: -----]
    spliting_of_path = re.split(r'Path\s\d+:', b)  #use this in report if path is in this  format [Path 1: -----]

    c = spliting_of_path[1:]
    for d in c:       
        end_path = re.findall(r'\s*Endpoint:\s+\(\S*\)\s*(.*)',d)
        begin_point = re.findall(r'\s*Startpoint:\s+\(\S*\)\s*(.*)',d)
        path_group = re.findall(r'\s*Group:\s+(.*)',d)
        library_setup = re.findall(r'\s*Setup:-\s+([-+ ]?\d\.\d+)', d)
        slack_time=re.findall(r'\s*Slack:=\s*([-+ ]?\d+\.\d+)',d)
        table=re.findall(r'^#-*(.*)',d,re.S|re.M)[0].strip()
        latency=re.findall(r'\s*Arrival:=\s*(.*)',d)[0].split() 
        clock_edge=re.findall(r'\s*Clock Edge:\+\s*(.*)',d)[0].split()  
        skew=round(float(float(latency[0])-float(clock_edge[0])-float(latency[-1])),3)
        #clk_period=re.findall(r'\+ Phase Shift(.*)',d)[0].strip() 
        clk_period=1.2 
        
        head=table.split('\n')[0].split()
        headd=[]
        
        for i in head:
            if i=="#":
                pass
            else:
                headd.append(i.strip())
   
        

        try:cellindex=headd.index('Cell')
        except:pass
        try:fanoutindex=headd.index('Fanout')
        except:pass
        try:delayindex=headd.index('Delay')
        except:pass           
        try:arrindex=headd.index('Arrival')
        except:pass
        try:loadindex=headd.index('Load')
        except:pass
        try:netindex=headd.index('Net')
        except:pass


        #print(headd)
        #print(cellindex,fanoutindex,delayindex,arrindex,loadindex,netindex)
        
        fanout=0
        net_delay=0
        no_of_nets=0
        stages=0
        capacitance=0
        no_of_buffers=0
        no_of_inverters=0
        no_of_logic_gates=0
        buffer_delay=0
        inverter_delay=0
        logic_gate_delay=0
        total_delay=0
        no_of_register=0
        register_delay=0
        net_length_value=0
        

        a=re.split('#--+',table)
       
        
        e = re.split(r'\n',a[1])
        for line in e:
            split_data = line.split()
                        
        
            try:
                if ((split_data[fanoutindex] != '-') and (split_data[delayindex] != '-')):
                    fanout_value = int(split_data[fanoutindex])
                    net_delay_value = float(split_data[delayindex])
                    fanout += fanout_value
                    net_delay += net_delay_value
                    no_of_nets +=1
                    capacitance+=float(split_data[loadindex])
                 
                
                if ((split_data[fanoutindex] != '-') and (split_data[delayindex] !='-')) :
                    net_s=split_data[netindex]   
                    net_name= fr' {re.escape(net_s)}$'
                    daa=re.findall(f'\d*\.\d*\s*Total\s*(\d*\.\d*)\s*\d*\.\d*\s*Total\s*\d*\s*\d*\s*\d*\s*{net_name}',nets_data,re.M)
                    net_length_value += round(float(daa[0]),3)
                    #print(net_name,daa[0])
                    
                name=split_data[cellindex]    
                cell_type=re.findall(f'(.*) , {name}',cell_data)
                #print(cell_type)
                if (cell_type[0] == "BUFFER"): 
                   no_of_buffers +=1
                   buffer_delay += float(split_data[delayindex])

                
                elif  (cell_type[0] == "INVERTER"):
                   no_of_inverters +=1
                   inverter_delay += float(split_data[delayindex])
                elif  (cell_type[0] == "SEQUENTIAL"):
                   no_of_register +=1
                   register_delay += float(split_data[delayindex])
                elif (cell_type[0] == "COMBINATIONAL") :
                    no_of_logic_gates +=1
                    logic_gate_delay +=float(split_data[delayindex])
                
            except Exception as e:pass
            #time.sleep(2)
        #print()    
        #exit()
        
        total_delay=buffer_delay+logic_gate_delay+inverter_delay+net_delay
        
        buff_del_percent = (buffer_delay / total_delay * 100) if total_delay > 0 else 0
        inv_del_percent = (inverter_delay / total_delay * 100) if total_delay > 0 else 0
        logic_del_percent = (logic_gate_delay / total_delay * 100) if total_delay > 0 else 0
        net_del_percent = (net_delay / total_delay * 100) if total_delay > 0 else 0
        #print(no_of_buffers)        
                   
    

        # Store results for CSV
        results.append({
            'begin_point': begin_point[0],
            'end_path': end_path[0],
            'path_group': path_group[0],
            'library_setup': library_setup[0],
            'fanout': fanout,                                                                                         
            'net_delay': net_delay,
            'no_of_Nets': int(no_of_nets),
            'stages': int(no_of_nets)+1,
            'cap':capacitance,
            'slack':slack_time[0],
            'capture_latency(CL)':latency[0],
            'launch_latency(LL)':latency[-1],
            'skew(CL-LL)':skew,
            'buffer_count':no_of_buffers,
            'bufferDelay':buffer_delay,            
            'inverter_count':no_of_inverters,
            'inverterDelay':inverter_delay,
            'logic_gates_count':no_of_logic_gates,
            'logicDelay':round(logic_gate_delay,3),
            'totalDelay':total_delay,
            'buf_del_per':round(buff_del_percent,3),
            'inv_del_per':round(inv_del_percent,3),
            'logic_del_per':round(logic_del_percent,3),
            'net_del_per':round(net_del_percent,3),
            'net_Length':round(net_length_value,3),
            'CLK_PERIOD':clk_period

            })








 # Save results to CSV

    fieldnames = ['begin_point' ,'end_path', 'path_group','library_setup','fanout','net_delay','no_of_Nets','stages','cap','slack','capture_latency(CL)','launch_latency(LL)','skew(CL-LL)','buffer_count','inverter_count','logic_gates_count','bufferDelay','inverterDelay','logicDelay','totalDelay','buf_del_per','inv_del_per','logic_del_per','net_del_per','net_Length','CLK_PERIOD']

    save_to_csv(results, output_file, fieldnames, 1)  # Change 1 to 0 if appending
    print("result is saved in {}".format(output_file))

####################################################################

func1(file_path,net_length_file,cells_group_file,output_file)
func1(file_path1,net_length_file,cells_group_file,output_file1)
        

